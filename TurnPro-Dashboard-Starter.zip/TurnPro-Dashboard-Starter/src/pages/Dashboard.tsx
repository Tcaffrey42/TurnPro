import Sidebar from '../components/Sidebar';

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-black text-white flex">
      <Sidebar />
      <main className="flex-1 p-8">
        <h1 className="text-4xl font-bold">
          TURN<span className="text-red-500">PRO</span>
        </h1>
        <p className="text-zinc-400 mt-2">
          Apartment Turn Operating System
        </p>

        <div className="grid grid-cols-6 gap-4 mt-8">
          {[
            ["Active Turns","126"],
            ["Units Ready","42"],
            ["Avg Turn Time","4.3 Days"],
            ["Occupancy","96.8%"],
            ["Revenue","$208,450"],
            ["Vendor SLA","98.4%"],
          ].map(([title,value])=>(
            <div key={title} className="rounded-2xl bg-zinc-900 border border-zinc-800 p-5">
              <div className="text-zinc-400 text-sm">{title}</div>
              <div className="text-3xl font-bold mt-3">{value}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-3 gap-6 mt-8">
          <section className="col-span-2 rounded-2xl bg-zinc-900 p-6 border border-zinc-800">
            <h2 className="text-xl font-semibold mb-4">Turn Pipeline</h2>
            <p>Notice → Paint → Cleaning → Inspection → Rent Ready</p>
          </section>

          <section className="rounded-2xl bg-zinc-900 p-6 border border-zinc-800">
            <h2 className="text-xl font-semibold mb-4">AI Insights</h2>
            <ul className="space-y-3 text-sm">
              <li>• 17 units could finish one day earlier.</li>
              <li>• Building 12 has highest turn time.</li>
              <li>• ABC Painting is at 98% SLA.</li>
            </ul>
          </section>
        </div>
      </main>
    </div>
  );
}
