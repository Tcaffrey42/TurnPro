export default function Sidebar() {
  const items=[
    'Dashboard','Turns','Properties','Vendors',
    'Scheduling','Inspections','Analytics','AI','Settings'
  ];

  return (
    <aside className="w-72 bg-zinc-950 border-r border-zinc-800 p-6">
      <h2 className="text-3xl font-bold">
        TURN<span className="text-red-500">PRO</span>
      </h2>

      <nav className="mt-10 space-y-3">
        {items.map(i=>(
          <button
            key={i}
            className="w-full text-left rounded-xl px-4 py-3 hover:bg-red-600 transition"
          >
            {i}
          </button>
        ))}
      </nav>
    </aside>
  );
}
